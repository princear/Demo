import React, { Component } from 'react';
import {Button, View, Image, ImageBackground, Text,Dimensions,BackHandler, TouchableOpacity, Linking,StyleSheet, Alert } from "react-native";

import { PieChart } from 'react-native-svg-charts'
import { widthPercentageToDP as wp,heightPercentageToDP as hp } from "react-native-responsive-screen";


export default class ChooseColor extends Component {

    

  constructor(props){
    super(props);
    this.state = {
        selectedSlice: {
            label: '',
            value: '',
        },
        labelWidth: 0
    }
    
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
}
      state = {
        height: 0,
        width: 0,
    }

    
    componentWillMount() {
      BackHandler.addEventListener('hardwareBackPress', this.handleBackButtonClick);
      
  }

  componentWillUnmount() {
      BackHandler.removeEventListener('hardwareBackPress', this.handleBackButtonClick);
  }
  
    handleBackButtonClick() {
  
      this.props.route.params.onGoBack();
      this.props.navigation.goBack();
      return true;
  }

    goBack = () => {
      this.props.route.params.onGoBack();
      this.props.navigation.goBack();
  }

      
    render(){

      const { navigation } = this.props;  
      const seasonname = this.props.route.params.seasonname;

      const Mid = this.props.route.params.Mid;
      const cid = this.props.route.params.cid;
      const cname = this.props.route.params.cname;
      const Mname = this.props.route.params.Mname;
      const {labelWidth, selectedSlice} = this.state;
      const {label, value} = selectedSlice;
      const keys = ['Red', 'Orange', 'Yellow', 'Green', 'LightBlue','Purple','Violet'];
      const values = [35, 30, 30, 30, 30,30,30];
      const colors = ['#FFA89E', '#FED583', '#FFF184', '#C2E39C', '#A9E7FC','#C6A7FE','#7f00ff'];
      const data = keys.map((key, index) => {
          return {
              key,
              labelRadius:keys[index],
              value: values[index],
              svg: {fill: colors[index]},
              arc: {outerRadius: label === key ? '95%' : '85%', padAngle: 0},
              
              
              onPress: () => { this.props.navigation.navigate('ProductList',
                {
                  selectedSlice: key,
                  seasonname:seasonname,
                  Mid:Mid,
                  Mname:Mname,
                  cname:cname,
                  cid:cid,
                  colorid:index + 1
                } //{label: key, value: values[index]}}
              ), this.setState({selectedSlice: {label: key, value: values[index]}}); console.log(key, index)}
          }
      })

      const {width, height} = Dimensions.get('window');
        return(

            <ImageBackground style={{ flex: 1, width:'100%',bottom:0,top:0,bottom:-40,position:'absolute'  }} source={require('../../assets/images/bgbtmrain.png')} >
           
         
                
                <TouchableOpacity
                style={{ marginTop: 10, width: 50, height: 50, justifyContent: 'center',paddingLeft:10 }}
                onPress={() => this.goBack()}
               >
                <Image style={{ height:50,resizeMode:'contain',alignSelf:'center',width:100 }}
                    source={require('../../assets/images/back.png')}
                    />
              </TouchableOpacity>
                
                <View style={{height:60,marginTop:0}}>
                    <ImageBackground style={{height:hp('10%'),paddingBottom:10,resizeMode:'cover',justifyContent:'center' }}
                    source={require('../../assets/images/headerBG.png')}
                   
                   >
                    <View style={{flex:1,alignItems:'flex-start',paddingLeft:50,marginTop:10,paddingTop:5,paddingBottom:5}}>
                            <Text style={{fontFamily: "FredokaOne-Regular",fontSize:14,textTransform:'uppercase'}}>{seasonname}</Text>
                            <Text style={{fontSize:8,}}>April 20 (9:37 am) June 21(3:31 am)</Text>

                    </View>
                       </ImageBackground>
                    
                </View>

                <View style={{marginTop:20}}>
                    <Text style={{textTransform:'uppercase',fontFamily: "FredokaOne-Regular",fontSize:14,textAlign:'center'}}>select color</Text>
                 </View>
               

                {/* <Text style={{position:'absolute',top:hp("35%"),right:wp("30%"),zIndex:1}}>Red</Text>
                <Text style={{position:'absolute',top:height * .50,right:width * .15,zIndex:1}}>Orange</Text>
                <Text style={{position:'absolute',top:'63%',right:'20%',zIndex:1}}>Yellow</Text>
                <Text style={{position:'absolute',top:'67%',right:'47%',zIndex:1}}>Green</Text>
                <Text style={{position:'absolute',top:'60%',left:'15%',zIndex:1}}>LightBlue</Text>
                <Text style={{position:'absolute',top:'45%',left:'15%',zIndex:1}}>Purple</Text>
                <Text style={{position:'absolute',top:hp('35%'),left:'30%',zIndex:1}}>Violet</Text> */}
                 <View style={{ justifyContent: 'center',position:'relative'}}>
                 <Text style={{position:'absolute',top:hp("15%"),right:wp("30%"),zIndex:1}}>Red</Text>
                <Text style={{position:'absolute',top:hp("25"),right:wp("15"),zIndex:1}}>Orange</Text>
                <Text style={{position:'absolute',top:hp('40%'),right:wp('20%'),zIndex:1}}>Yellow</Text>
                <Text style={{position:'absolute',top:hp('45%'),right:wp('47%'),zIndex:1}}>Green</Text>
                <Text style={{position:'absolute',top:hp('40%'),left:wp('18%'),zIndex:1}}>LightBlue</Text>
                <Text style={{position:'absolute',top:hp('25%'),left:wp('15%'),zIndex:1}}>Purple</Text>
                <Text style={{position:'absolute',top:hp('12%'),left:wp('32%'),zIndex:1}}>Violet</Text>
              <PieChart
                  style={{ height:hp("60%"),width:wp("100%"),alignSelf:'center', }}
                  outerRadius={ '100%' }
                  innerRadius={ '20%' }
                  data={data}
                 
              />

              <ImageBackground 
               source={require('../../assets/images/spread.png')}
              style={styles.catcircle}
            
              >
             <TouchableOpacity style={{flex:1,justifyContent:'center',paddingTop:20}}
             onPress={()=>{Alert.alert('Press Center')}}
             >
                <Text style={{textAlign:'center',fontFamily: "FredokaOne-Regular",fontSize:26}}>EAT</Text>
                <Text style={{textTransform:'uppercase',textAlign:'center',fontFamily: "FredokaOne-Regular",fontSize:10,paddingTop:10}} >April Fruits</Text>

              </TouchableOpacity>
              </ImageBackground>
              {/* <Text
                  onLayout={({ nativeEvent: { layout: { width }}}) => {
                  this.setState({ labelWidth: width});
              }}
                  style={{
                  position: 'absolute',
                  left: deviceWidth / 2 - labelWidth / 2,
                  textAlign: 'center'
              }}>
                   {`${label} \n ${value}`} 
              </Text> */}
          </View>
       
              {/* <ImageBackground 
               source={require('../../assets/images/spread.png')}
              style={styles.catcircle}
            
              >
             <TouchableOpacity style={{flex:1,justifyContent:'center',paddingTop:20}}
             onPress={()=>{Alert.alert('Press Center')}}
             >
                <Text style={{textAlign:'center',fontFamily: "FredokaOne-Regular",fontSize:26}}>EAT</Text>
                <Text style={{textTransform:'uppercase',textAlign:'center',fontFamily: "FredokaOne-Regular",fontSize:12,paddingTop:10}} >April Fruits</Text>
              </TouchableOpacity>
              </ImageBackground> */}
            
             {/* <View style={styles.circle}>
               
              
               <TouchableOpacity style={styles.list}
               onPress={()=>{Alert.alert('Press Purple')}}
               >
                    <Text style={{color:'#7149BB',fontFamily: "FredokaOne-Regular",fontSize:20,transform:[{rotate:'-90deg'}]}}>Purple</Text>
               </TouchableOpacity>

               <TouchableOpacity style={styles.list1}
               onPress={()=>{this.props.navigation.navigate('ProductList')}}
               >
                  <Text style={{color:'#CD8986',fontFamily: "FredokaOne-Regular",transform:[{rotate:'-90deg'}],fontSize:20,marginTop:25,marginLeft:0}}>Red</Text>
                </TouchableOpacity>
               
               <TouchableOpacity style={styles.list2}
               onPress={()=>{Alert.alert('Press Orange')}}
               >
               <Text style={{marginRight:0,marginTop:25,color:'#C79C46',fontFamily: "FredokaOne-Regular",fontSize:20,transform:[{rotate:'-90deg'}]}}>Orange</Text>
               </TouchableOpacity> 
               <TouchableOpacity style={styles.list3}
               onPress={()=>{Alert.alert('Press Blue')}}
               >
               <Text style={{color:'#2B4992',fontFamily: "FredokaOne-Regular",fontSize:20,transform:[{rotate:'-90deg'}]}}>Blue</Text>
               </TouchableOpacity>   
               
               
              

             </View>
         */}

            </ImageBackground>
            
        )
    }
}



const styles = StyleSheet.create({

container:{ 
  flex:1,
    
    
},
catcircle:{
  position:'absolute',
  //borderWidth:1,
  //borderColor:'red',
  backgroundColor:'white',
  width:120,
  height:120,
  top:'30%',
  borderRadius:120/2,
  alignSelf:'center',
  overflow:'hidden',
  paddingTop:0,
  margin:10,
  zIndex:1,
  
  bottom:0
},
circle:{
  position:'relative',
  //borderWidth:1,
  //borderColor:'red',
  width:380,
  height:380,
  borderRadius:380/2,
  alignSelf:'center',
  overflow:'hidden',
  padding:0,
  margin:20,
  top:10
  //backgroundColor:'green'


},
list:{
position:'absolute',
top:0,
right:0,
width:'50%',
height:'50%',
overflow:'hidden',
backgroundColor:'#C8A7FE',
transform:[{translateX:-190},{rotate:'90deg'}],
},
list1:{
  position:'absolute',
  top:0,
  right:0,
  width:'50%',
  height:'50%',
  overflow:'hidden',
  backgroundColor:'#FEBDB7',
  transform:[{translateX:0},{rotate:'90deg'}]
  },

  list2:{
    position:'absolute',
    top:0,
    right:0,
    width:'50%',
    height:'50%',
    overflow:'hidden',
    backgroundColor:'#FFD686',
    transform:[{translateY:190},{rotate:'90deg'}]
    },
  
    list3:{
      position:'absolute',
      bottom:0,
      left:0,
      width:'50%',
      height:'50%',
      overflow:'hidden',
      backgroundColor:'#97AFEF',
      transform:[{translateY:0},{rotate:'90deg'}]
      },
       
// data:{
// position:'absolute',
// left:'-100%',
// width:'200%',
// height:'200%',
// textAlign:'center',
// transform: [{skewY: '60deg'},{rotate: '15deg'}], 
// padding:20 
// }

})
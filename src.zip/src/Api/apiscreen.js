export class apiscreen{
   
    // static base_url ="http://3.131.133.154/iebfevent/api/";
    static base_url ="http://rainbow.delimp.world/";
    static register = "api/register";
    static login = "api/login";
    static ForgetPass = "api/forgot_password"; 
    static ResetPass  = "api/reset_password";
    static GetCountries = "api/get_country_list";
    static GetSeason  = "api/get_season_list"
    static GetMonths = "api/get_months_list/"
    static Getfood = "api/get_food_cat"
    static GetItems = "api/get_item_list"
    static Getrecipe = "api/get_recipe_list"
    static GetProfile = "api/getprofile"
     
}
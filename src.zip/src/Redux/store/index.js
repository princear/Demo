import { createStore } from 'redux'
import CartItems from '../reducers/CartItems'

export default store = createStore(CartItems);